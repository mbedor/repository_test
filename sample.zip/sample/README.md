# Prevent VMs with Public IPs
### [KFI : FISEC-483](https://test1.com) 
### [Documentation : Confluence](https://test2.com/Prevent+VMs+With+Public+IPs)

- [Révisions](#révisions)
- [Introduction](#intro)
- [Ressources concernées](#ressources)
- [Solution de remédiation validée pour l’existant](#solution_existant)
- [Solution de remédiation validée pour le futur](#solution_futur)
- [Solution](#solution)
- [Scénarios de test](#test)
- [Résultats des tests](#résultats)
<br/><br/>

### Révisions <a name = "révisions"></a>

| Version | Date | Identifiant | Commentaire |
| ---: | :---: | :---: | :--- |
| 1.0.0.0 | Juin 2021 | @yu5676 | Version initiale |
<br/>

### Introduction <a name = "intro"></a>

Cette politique a pour objectif de bloquer les ressources NIC (*Network Interface*) qui sont configurées avec une adresse IP publique à l'exception de celles qui ont un *subnet* lié à un *databrick* ou à toute autre application que l'on désignera. La liste de *subnets* associés aux exceptions sera fournie lors de l'assignation de la politique (*ToBeChosen*).

```
      "subnets": {
        "type": "Array",
        "metadata": {
          "displayName": "Subnet withing VNET configured for Databricks and other resources",
          "description": "The subnet IDs that can have public IPs"
        },
        "defaultValue": [
          "ToBeChosen"
        ]
      }
```
Ceci dit, toutes les ressources NIC (*Microsoft.Network/networkInterfaces*) qui ne sont pas configurées avec une adresse IP publique sont conformes selon cette politique, de même que celles qui sont configurées avec une adresse IP publique mais dont le *subnet* est associé à un *databrick* ou à toute autre application faisant partie de l'exception. Les effets optés pour cette politique sont *Audit*, *Deny* et *Disabled*. Le premier effet étant celui qui s'applique par défaut.
<br/><br/>

### Ressources concernées <a name = "ressources"></a>

Les ressources concernées sont: le champs *Adresse IP Publique* des ressources NIC (*Network Interface*), ainsi que le *subnet* associé afin de gérer une éventuelle exception.
<br/><br/>

### Solution de remédiation validée pour l’existant <a name = "solution_existant"></a>

 Avoir une politique de type *Audit* par défaut, mais qui, plus tard pourra appliquer l'effet *Deny* quand toutes les exceptions auront été clarifiées. Pour le moment, on sait que l'exception pour les adresses IP publiques va s'appliquer aux *databricks* qui seront configurés dans des *Virtual Networks*. Une liste de *subnets* associés seront donc passés lors de l'assignation de la politique pour s'assurer que les adresses IP publiques des NICs reliés aux *databricks* seront permis.
<br/><br/>

### Solution de remédiation validée pour le futur <a name = "solution_futur"></a>

Sans Objet.
<br/><br/> 

### Solution <a name = "solution"></a>

Auditer les ressources NIC (*Network Interface*) non conformes en se basant sur deux paramètres: l'adresse IP publique ainsi que le *subnet* associé au NIC. Pour qu'une ressource NIC soit conforme, il faut qu'elle vérifie l'une des deux conditions suivantes:
- La ressource NIC ne possède pas une adresse IP publique.
- La ressource NIC possède une adresse IP publique, mais utilise un *subnet* qui se trouve dans la liste d'exceptions passées lors de l'assignation de la politique.
<br/><br/>

### Scénarios de test <a name = "test"></a>

- Créer la politique au niveau du *Management Group* de Lab.
- Utiliser des ressources NIC (*Network Interface*), les uns configurées avec une adresse IP publique et les autres sans une adresse IP.
- Assigner la politique tout en passant une liste de *subnets*.
- Analyser la conformité de la ressource.
- Répéter le processus d'analyse de la conformité autant de fois que nécessaire en jouant sur la liste de *subnets*.

- Pour l'existant :
    - Cas 1: On a au préalable une vingtaine de ressources NIC dont la plupart ne sont pas configuré avec une adresse IP publique. Lors d'une première assignation de la politique, une liste de *subnets* est passée en paramètre. Comme attendu, la plupart des ressources NIC apparaissent conformes dans le tableau de la conformité étant donné que la majorité d'entre elles ne sont pas configurée avec une adresse IP publique. On prend en exemple une ressource non conforme, et quand on la regarde de près, on remarque qu'elle est configurée avec une adresse IP publique et que son *subnet* associé ne fais pas parti de la liste de *subnets* passés en paramètre.
    - Cas 2: On supprime l'assignation courante, on crée une nouvelle assignation, on prend le *subnet* de la ressource non conforme indiquée plus haut, et on le rajoute dans la liste des *subnets* qui traitent les exceptions des ressources pouvant être configurées avec une adresse IP publique. Après quelques minutes, le tableau de la conformité a changé, la ressource mentionnée plus haut qui était non conforme devient à présent conforme, ce qui prouve qu'on peut contrôler les exceptions à partir d'une liste de *subnets* qui sera passés en paramètre lors de l'assignation de la politique.

- Pour le futur :
    - Sans Objet.
<br/><br/>

### Résultats des tests <a name = "résultats"></a>

N.B.: "Audit Network Interfaces Configured With Public IP" qu'on voit dans les saisies d'écran ci-dessous, est le nom de la politique dans l'environnement de test, et donc correspond à la politique actuelle "Prevent VMs with Public IPs".

 ![Alt text](images/img01.jpg?raw=true "Résultat")
 ![Alt text](images/img02.jpg?raw=true "Résultat")
 ![Alt text](images/img03.jpg?raw=true "Résultat")
 ![Alt text](images/img04.jpg?raw=true "Résultat")
 ![Alt text](images/img05.jpg?raw=true "Résultat")
 ![Alt text](images/img06.jpg?raw=true "Résultat")
 ![Alt text](images/img07.jpg?raw=true "Résultat")
 ![Alt text](images/img08.jpg?raw=true "Résultat")
 ![Alt text](images/img09.jpg?raw=true "Résultat")
 ![Alt text](images/img10.jpg?raw=true "Résultat")
 ![Alt text](images/img11.jpg?raw=true "Résultat")
 ![Alt text](images/img12.jpg?raw=true "Résultat")
 ![Alt text](images/img13.jpg?raw=true "Résultat")
 ![Alt text](images/img14.jpg?raw=true "Résultat")
 ![Alt text](images/img15.jpg?raw=true "Résultat")